/**
 * 
 */
/**
 * 
 */
module ProyectobUENO {
	requires java.sql;
	requires java.desktop;
	requires junit;
	requires org.junit.jupiter.api;
}